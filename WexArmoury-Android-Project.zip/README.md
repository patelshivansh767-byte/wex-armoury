# WEX ARMOURY // NATIVE ANDROID GAMING HUD
Optimized specifically for Xiaomi Redmi Note 10T 5G (Android 13 / MIUI 14).

## Project Structure
- settings.gradle (Root configuration)
- build.gradle (Android Gradle Plugin 8.2.2)
- gradle.properties (JVM & AndroidX configs)
- app/build.gradle (Application module, compileSdk 34, Java 17)
- app/src/main/AndroidManifest.xml (Permissions & Foreground service)
- app/src/main/java/com/wex/armoury/MainActivity.java (WebView host & AndroidBridge)
- app/src/main/java/com/wex/armoury/FloatingOverlayService.java (3-layer overlay & Choreographer FPS)
- app/src/main/assets/index.html (Offline, self-contained cyber-tactical HUD UI)
- .github/workflows/build.yml (GitHub Actions workflow to compile APK directly)

## Building the APK
### Option 1: GitHub Actions (No local Android Studio needed)
1. Push this folder to a GitHub repository.
2. Go to the "Actions" tab in GitHub.
3. The "Build Wex Armoury APK" workflow will build and upload the debug APK artifact automatically.

### Option 2: Android Studio
1. Open Android Studio -> Open -> select this extracted directory.
2. Let Gradle sync (Gradle 8.5 with JDK 17).
3. Connect your Xiaomi Redmi Note 10T 5G with USB Debugging enabled.
4. Click Run (Shift + F10).
