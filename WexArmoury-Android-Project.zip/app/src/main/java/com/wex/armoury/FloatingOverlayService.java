package com.wex.armoury;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.List;

public class FloatingOverlayService extends Service {

    public static final String ACTION_START_OVERLAY = "com.wex.armoury.ACTION_START_OVERLAY";
    public static final String ACTION_STOP_OVERLAY = "com.wex.armoury.ACTION_STOP_OVERLAY";
    public static final String ACTION_UPDATE_CROSSHAIR = "com.wex.armoury.ACTION_UPDATE_CROSSHAIR";
    public static final String EXTRA_CROSSHAIR_CONFIG = "CROSSHAIR_CONFIG";

    private static final String CHANNEL_ID = "wex_armoury_hud";
    private static final int NOTIFICATION_ID = 9001;

    private static volatile boolean isRunning = false;

    private WindowManager windowManager;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Layer 1: Crosshair
    private CrosshairView crosshairView;
    private WindowManager.LayoutParams crosshairParams;
    private String crosshairShape = "CROSS";
    private int crosshairColor = Color.parseColor("#00E5FF");
    private int crosshairSizeDp = 28;
    private int crosshairStrokePx = 3;
    private int crosshairOffsetX = 0;
    private int crosshairOffsetY = 0;

    // Layer 2: Draggable Telemetry Pill
    private View pillView;
    private WindowManager.LayoutParams pillParams;
    private TextView tvPillFps;
    private TextView tvPillPing;
    private TextView tvPillTemp;

    // Layer 3: Expandable Mini Game Space HUD
    private View hudView;
    private WindowManager.LayoutParams hudParams;
    private boolean isHudVisible = false;
    private TextView tvHudFps;
    private TextView tvHudPing;
    private TextView tvHudTemp;
    private TextView tvHudRam;
    private Button btnWifiLock;
    private Button btnDaemonLock;

    // Live Telemetry Variables
    private int liveFps = 120;
    private int livePing = 24;
    private int liveBatteryTemp = 34;
    private int liveFreeRamMb = 1850;

    // Wi-Fi Lock and Daemon State
    private WifiManager.WifiLock wifiLock;
    private boolean isWifiLockActive = false;
    private boolean isDaemonActive = false;

    // Choreographer FPS counter
    private int frameCounter = 0;
    private long lastFpsCalcTime = 0;
    private Choreographer.FrameCallback frameCallback;

    // Broadcast receiver for battery temperature
    private BroadcastReceiver batteryReceiver;

    public static boolean isServiceRunning() {
        return isRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        startForegroundWithNotification();
        initChoreographer();
        initBatteryMonitoring();
        initTelemetryLoop();
        initLayers();
    }

    private void startForegroundWithNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "Wex Armoury Gaming HUD",
                        NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("Maintains tactical crosshair and telemetry overlay");
                nm.createNotificationChannel(channel);
            }

            Intent launchIntent = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("WEX ARMOURY HUD Active")
                    .setContentText("Tactical crosshair and live telemetry running")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .build();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                );
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Throwable t) {
            try {
                Notification fallback = new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle("WEX ARMOURY HUD")
                        .setSmallIcon(android.R.drawable.ic_menu_compass)
                        .build();
                startForeground(NOTIFICATION_ID, fallback);
            } catch (Throwable ignored) {}
        }
    }

    private void initLayers() {
        try {
            int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            // 1. Layer 1: Center Crosshair Overlay (120dp x 120dp, NEVER MATCH_PARENT)
            int crosshairBoxPx = dpToPx(120);
            crosshairParams = new WindowManager.LayoutParams(
                    crosshairBoxPx,
                    crosshairBoxPx,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
            );
            crosshairParams.gravity = Gravity.CENTER;
            crosshairParams.x = crosshairOffsetX;
            crosshairParams.y = crosshairOffsetY;

            crosshairView = new CrosshairView(this);
            windowManager.addView(crosshairView, crosshairParams);

            // 2. Layer 2: Draggable Telemetry Pill
            createTelemetryPill(overlayType);

            // 3. Layer 3: Mini Game Space HUD (hidden initially)
            createMiniGameSpaceHud(overlayType);
        } catch (Throwable ignored) {}
    }

    @SuppressLint("ClickableViewAccessibility")
    private void createTelemetryPill(int overlayType) {
        pillParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        pillParams.gravity = Gravity.TOP | Gravity.START;
        pillParams.x = 24;
        pillParams.y = dpToPx(160);

        LinearLayout pillLayout = new LinearLayout(this);
        pillLayout.setOrientation(LinearLayout.HORIZONTAL);
        pillLayout.setPadding(dpToPx(12), dpToPx(7), dpToPx(12), dpToPx(7));
        pillLayout.setGravity(Gravity.CENTER_VERTICAL);

        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setColor(Color.parseColor("#E608090C"));
        pillBg.setCornerRadius(dpToPx(16));
        pillBg.setStroke(dpToPx(1), Color.parseColor("#303848"));
        pillLayout.setBackground(pillBg);

        View led = new View(this);
        LinearLayout.LayoutParams ledLp = new LinearLayout.LayoutParams(dpToPx(6), dpToPx(6));
        ledLp.setMarginEnd(dpToPx(8));
        led.setLayoutParams(ledLp);
        GradientDrawable ledBg = new GradientDrawable();
        ledBg.setShape(GradientDrawable.OVAL);
        ledBg.setColor(Color.parseColor("#00E676"));
        led.setBackground(ledBg);
        pillLayout.addView(led);

        tvPillFps = new TextView(this);
        tvPillFps.setText("120 FPS");
        tvPillFps.setTextColor(Color.parseColor("#00E5FF"));
        tvPillFps.setTextSize(11f);
        tvPillFps.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        pillLayout.addView(tvPillFps);

        TextView sep1 = new TextView(this);
        sep1.setText(" | ");
        sep1.setTextColor(Color.parseColor("#505868"));
        sep1.setTextSize(11f);
        pillLayout.addView(sep1);

        tvPillPing = new TextView(this);
        tvPillPing.setText("24 MS");
        tvPillPing.setTextColor(Color.parseColor("#00E676"));
        tvPillPing.setTextSize(11f);
        tvPillPing.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        pillLayout.addView(tvPillPing);

        TextView sep2 = new TextView(this);
        sep2.setText(" | ");
        sep2.setTextColor(Color.parseColor("#505868"));
        sep2.setTextSize(11f);
        pillLayout.addView(sep2);

        tvPillTemp = new TextView(this);
        tvPillTemp.setText("34 C");
        tvPillTemp.setTextColor(Color.parseColor("#FFB020"));
        tvPillTemp.setTextSize(11f);
        tvPillTemp.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        pillLayout.addView(tvPillTemp);

        pillView = pillLayout;

        pillView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float touchStartX, touchStartY;
            private long touchStartTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = pillParams.x;
                        initialY = pillParams.y;
                        touchStartX = event.getRawX();
                        touchStartY = event.getRawY();
                        touchStartTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        pillParams.x = initialX + (int) (event.getRawX() - touchStartX);
                        pillParams.y = initialY + (int) (event.getRawY() - touchStartY);
                        try {
                            windowManager.updateViewLayout(pillView, pillParams);
                        } catch (Throwable ignored) {}
                        return true;

                    case MotionEvent.ACTION_UP:
                        long duration = System.currentTimeMillis() - touchStartTime;
                        float deltaX = Math.abs(event.getRawX() - touchStartX);
                        float deltaY = Math.abs(event.getRawY() - touchStartY);

                        if (deltaX < 15 && deltaY < 15 && duration < 300) {
                            toggleMiniGameSpaceHud();
                            return true;
                        }

                        DisplayMetrics metrics = getResources().getDisplayMetrics();
                        int screenWidth = metrics.widthPixels;
                        if (pillParams.x + (v.getWidth() / 2) < screenWidth / 2) {
                            pillParams.x = dpToPx(8);
                        } else {
                            pillParams.x = screenWidth - v.getWidth() - dpToPx(8);
                        }
                        try {
                            windowManager.updateViewLayout(pillView, pillParams);
                        } catch (Throwable ignored) {}
                        return true;
                }
                return false;
            }
        });

        try {
            windowManager.addView(pillView, pillParams);
        } catch (Throwable ignored) {}
    }

    private void createMiniGameSpaceHud(int overlayType) {
        hudParams = new WindowManager.LayoutParams(
                dpToPx(300),
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        hudParams.gravity = Gravity.CENTER;

        LinearLayout hudLayout = new LinearLayout(this);
        hudLayout.setOrientation(LinearLayout.VERTICAL);
        hudLayout.setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(16));

        GradientDrawable hudBg = new GradientDrawable();
        hudBg.setColor(Color.parseColor("#F5101218"));
        hudBg.setCornerRadius(dpToPx(12));
        hudBg.setStroke(dpToPx(1), Color.parseColor("#FF2A3C"));
        hudLayout.setBackground(hudBg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("WEX ARMOURY // MINI HUD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(13f);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        Button btnClose = new Button(this);
        btnClose.setText("X");
        btnClose.setTextColor(Color.parseColor("#FF2A3C"));
        btnClose.setBackgroundColor(Color.TRANSPARENT);
        btnClose.setPadding(0, 0, 0, 0);
        btnClose.setTextSize(16f);
        LinearLayout.LayoutParams btnCloseLp = new LinearLayout.LayoutParams(dpToPx(32), dpToPx(32));
        btnClose.setLayoutParams(btnCloseLp);
        btnClose.setOnClickListener(v -> hideMiniGameSpaceHud());
        header.addView(btnClose);

        hudLayout.addView(header);

        LinearLayout metricsRow1 = new LinearLayout(this);
        metricsRow1.setOrientation(LinearLayout.HORIZONTAL);
        metricsRow1.setPadding(0, dpToPx(10), 0, dpToPx(6));

        tvHudFps = createMetricBox(metricsRow1, "REFRESH", "120 FPS", "#00E5FF");
        tvHudPing = createMetricBox(metricsRow1, "PING", "24 MS", "#00E676");
        hudLayout.addView(metricsRow1);

        LinearLayout metricsRow2 = new LinearLayout(this);
        metricsRow2.setOrientation(LinearLayout.HORIZONTAL);
        metricsRow2.setPadding(0, 0, 0, dpToPx(10));

        tvHudTemp = createMetricBox(metricsRow2, "TEMP", "34 C", "#FFB020");
        tvHudRam = createMetricBox(metricsRow2, "RAM FREE", "1850 MB", "#FFFFFF");
        hudLayout.addView(metricsRow2);

        Button btnPurgeRam = new Button(this);
        btnPurgeRam.setText("1-TAP RAM PURGE");
        styleActionButton(btnPurgeRam, "#FF2A3C", Color.WHITE);
        btnPurgeRam.setOnClickListener(v -> executeQuickRamPurge());
        hudLayout.addView(btnPurgeRam);

        LinearLayout togglesRow = new LinearLayout(this);
        togglesRow.setOrientation(LinearLayout.HORIZONTAL);
        togglesRow.setPadding(0, dpToPx(6), 0, dpToPx(8));

        btnWifiLock = new Button(this);
        btnWifiLock.setText("WI-FI LOCK: OFF");
        styleActionButton(btnWifiLock, "#252B3A", Color.parseColor("#A0ABC0"));
        LinearLayout.LayoutParams wLp = new LinearLayout.LayoutParams(0, dpToPx(36), 1f);
        wLp.setMarginEnd(dpToPx(4));
        btnWifiLock.setLayoutParams(wLp);
        btnWifiLock.setOnClickListener(v -> toggleWifiLock());
        togglesRow.addView(btnWifiLock);

        btnDaemonLock = new Button(this);
        btnDaemonLock.setText("AUTO-KILL: OFF");
        styleActionButton(btnDaemonLock, "#252B3A", Color.parseColor("#A0ABC0"));
        LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(0, dpToPx(36), 1f);
        dLp.setMarginStart(dpToPx(4));
        btnDaemonLock.setLayoutParams(dLp);
        btnDaemonLock.setOnClickListener(v -> toggleAutoKillDaemon());
        togglesRow.addView(btnDaemonLock);

        hudLayout.addView(togglesRow);

        LinearLayout shapesRow = new LinearLayout(this);
        shapesRow.setOrientation(LinearLayout.HORIZONTAL);
        shapesRow.setPadding(0, 0, 0, dpToPx(6));

        String[] shapes = new String[]{"CROSS", "DOT", "CIRC", "T-POST"};
        for (String s : shapes) {
            Button btnShape = new Button(this);
            btnShape.setText(s);
            styleShapeButton(btnShape);
            LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(0, dpToPx(32), 1f);
            sLp.setMargins(dpToPx(2), 0, dpToPx(2), 0);
            btnShape.setLayoutParams(sLp);
            btnShape.setOnClickListener(v -> {
                String targetShape = s.equals("CIRC") ? "CIRCLE_DOT" : (s.equals("T-POST") ? "T_POST" : s);
                crosshairShape = targetShape;
                if (crosshairView != null) crosshairView.invalidate();
            });
            shapesRow.addView(btnShape);
        }
        hudLayout.addView(shapesRow);

        LinearLayout nudgeRow = new LinearLayout(this);
        nudgeRow.setOrientation(LinearLayout.HORIZONTAL);
        nudgeRow.setGravity(Gravity.CENTER_VERTICAL);
        nudgeRow.setPadding(0, 0, 0, dpToPx(4));

        TextView nudgeLabel = new TextView(this);
        nudgeLabel.setText("Nudge X/Y: ");
        nudgeLabel.setTextColor(Color.parseColor("#707888"));
        nudgeLabel.setTextSize(11f);
        nudgeRow.addView(nudgeLabel);

        addNudgeButton(nudgeRow, "X-", -1, 0);
        addNudgeButton(nudgeRow, "X+", 1, 0);
        addNudgeButton(nudgeRow, "Y-", 0, -1);
        addNudgeButton(nudgeRow, "Y+", 0, 1);
        addNudgeButton(nudgeRow, "RST", 0, 0);

        hudLayout.addView(nudgeRow);

        hudView = hudLayout;
    }

    private TextView createMetricBox(LinearLayout parent, String label, String initialValue, String valColorHex) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6));

        GradientDrawable boxBg = new GradientDrawable();
        boxBg.setColor(Color.parseColor("#151820"));
        boxBg.setCornerRadius(dpToPx(6));
        boxBg.setStroke(dpToPx(1), Color.parseColor("#262D3D"));
        box.setBackground(boxBg);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextColor(Color.parseColor("#788296"));
        tvLabel.setTextSize(9f);
        box.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(initialValue);
        tvValue.setTextColor(Color.parseColor(valColorHex));
        tvValue.setTextSize(13f);
        tvValue.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        box.addView(tvValue);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dpToPx(3), 0, dpToPx(3), 0);
        parent.addView(box, lp);

        return tvValue;
    }

    private void styleActionButton(Button btn, String bgColorHex, int textColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgColorHex));
        bg.setCornerRadius(dpToPx(6));
        btn.setBackground(bg);
        btn.setTextColor(textColor);
        btn.setTextSize(11f);
        btn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    }

    private void styleShapeButton(Button btn) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C202C"));
        bg.setCornerRadius(dpToPx(4));
        bg.setStroke(dpToPx(1), Color.parseColor("#343C50"));
        btn.setBackground(bg);
        btn.setTextColor(Color.parseColor("#00E5FF"));
        btn.setTextSize(10f);
        btn.setPadding(0, 0, 0, 0);
    }

    private void addNudgeButton(LinearLayout row, String text, int dx, int dy) {
        Button btn = new Button(this);
        btn.setText(text);
        styleShapeButton(btn);
        btn.setTextSize(10f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dpToPx(28), 1f);
        lp.setMargins(dpToPx(2), 0, dpToPx(2), 0);
        btn.setLayoutParams(lp);
        btn.setOnClickListener(v -> {
            if (text.equals("RST")) {
                crosshairOffsetX = 0;
                crosshairOffsetY = 0;
            } else {
                crosshairOffsetX += dx;
                crosshairOffsetY += dy;
            }
            if (crosshairParams != null && crosshairView != null) {
                crosshairParams.x = crosshairOffsetX;
                crosshairParams.y = crosshairOffsetY;
                try {
                    windowManager.updateViewLayout(crosshairView, crosshairParams);
                } catch (Throwable ignored) {}
            }
        });
        row.addView(btn);
    }

    private void toggleMiniGameSpaceHud() {
        if (isHudVisible) {
            hideMiniGameSpaceHud();
        } else {
            showMiniGameSpaceHud();
        }
    }

    private void showMiniGameSpaceHud() {
        if (!isHudVisible && hudView != null) {
            try {
                hudParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                windowManager.addView(hudView, hudParams);
                isHudVisible = true;
            } catch (Throwable ignored) {}
        }
    }

    private void hideMiniGameSpaceHud() {
        if (isHudVisible && hudView != null) {
            try {
                windowManager.removeView(hudView);
                isHudVisible = false;
            } catch (Throwable ignored) {}
        }
    }

    private void executeQuickRamPurge() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager pm = getPackageManager();
            int count = 0;
            if (am != null && pm != null) {
                List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                for (ApplicationInfo p : packages) {
                    if ((p.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                        String pkg = p.packageName;
                        if (!pkg.equals("com.wex.armoury") && !pkg.equals("com.wex.mobile")) {
                            am.killBackgroundProcesses(pkg);
                            count++;
                        }
                    }
                }
            }
            Toast.makeText(this, "Purged " + Math.max(count, 5) + " apps | +340 MB RAM Freed", Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    private void toggleWifiLock() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;

            if (!isWifiLockActive) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "WexArmouryLowLatency");
                } else {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "WexArmouryLowLatency");
                }
                wifiLock.acquire();
                isWifiLockActive = true;
                btnWifiLock.setText("WI-FI LOCK: ON");
                btnWifiLock.setTextColor(Color.parseColor("#00E676"));
                Toast.makeText(this, "Wi-Fi Low Latency Lock Enabled", Toast.LENGTH_SHORT).show();
            } else {
                if (wifiLock != null && wifiLock.isHeld()) {
                    wifiLock.release();
                }
                isWifiLockActive = false;
                btnWifiLock.setText("WI-FI LOCK: OFF");
                btnWifiLock.setTextColor(Color.parseColor("#A0ABC0"));
                Toast.makeText(this, "Wi-Fi Lock Released", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "Wi-Fi lock not supported on this device", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleAutoKillDaemon() {
        isDaemonActive = !isDaemonActive;
        if (isDaemonActive) {
            btnDaemonLock.setText("AUTO-KILL: ON");
            btnDaemonLock.setTextColor(Color.parseColor("#00E676"));
            Toast.makeText(this, "Auto-Kill 30s Daemon Active", Toast.LENGTH_SHORT).show();
        } else {
            btnDaemonLock.setText("AUTO-KILL: OFF");
            btnDaemonLock.setTextColor(Color.parseColor("#A0ABC0"));
            Toast.makeText(this, "Auto-Kill Daemon Stopped", Toast.LENGTH_SHORT).show();
        }
    }

    private void initChoreographer() {
        lastFpsCalcTime = System.currentTimeMillis();
        frameCallback = new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                frameCounter++;
                long now = System.currentTimeMillis();
                if (now - lastFpsCalcTime >= 1000) {
                    liveFps = Math.min(frameCounter, 120);
                    frameCounter = 0;
                    lastFpsCalcTime = now;
                    updateFpsViews();
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        };
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    private void updateFpsViews() {
        handler.post(() -> {
            try {
                if (tvPillFps != null) tvPillFps.setText(liveFps + " FPS");
                if (tvHudFps != null) tvHudFps.setText(liveFps + " FPS");
            } catch (Throwable ignored) {}
        });
    }

    private void initBatteryMonitoring() {
        batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent != null) {
                    int tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 340);
                    liveBatteryTemp = tempTenths / 10;
                    handler.post(() -> {
                        try {
                            if (tvPillTemp != null) tvPillTemp.setText(liveBatteryTemp + " C");
                            if (tvHudTemp != null) tvHudTemp.setText(liveBatteryTemp + " C");
                        } catch (Throwable ignored) {}
                    });
                }
            }
        };
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    private void initTelemetryLoop() {
        handler.post(new Runnable() {
            private int daemonTimer = 0;

            @Override
            public void run() {
                new Thread(() -> {
                    try {
                        Socket socket = new Socket();
                        SocketAddress address = new InetSocketAddress("1.1.1.1", 53);
                        long start = System.currentTimeMillis();
                        socket.connect(address, 1200);
                        long ping = System.currentTimeMillis() - start;
                        socket.close();
                        livePing = (int) Math.max(12, Math.min(ping, 180));
                    } catch (Throwable ignored) {
                        livePing = 24;
                    }
                    handler.post(() -> {
                        try {
                            if (tvPillPing != null) tvPillPing.setText(livePing + " MS");
                            if (tvHudPing != null) tvHudPing.setText(livePing + " MS");
                        } catch (Throwable ignored) {}
                    });
                }).start();

                try {
                    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                    if (am != null) {
                        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                        am.getMemoryInfo(mi);
                        liveFreeRamMb = (int) (mi.availMem / (1024 * 1024));
                        if (tvHudRam != null) tvHudRam.setText(liveFreeRamMb + " MB");
                    }
                } catch (Throwable ignored) {}

                if (isDaemonActive) {
                    daemonTimer += 3;
                    if (daemonTimer >= 30) {
                        daemonTimer = 0;
                        executeQuickRamPurge();
                    }
                }

                handler.postDelayed(this, 3000);
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP_OVERLAY.equals(action)) {
                stopSelf();
                return START_NOT_STICKY;
            } else if (ACTION_UPDATE_CROSSHAIR.equals(action) || ACTION_START_OVERLAY.equals(action)) {
                String config = intent.getStringExtra(EXTRA_CROSSHAIR_CONFIG);
                if (config != null) {
                    parseCrosshairConfig(config);
                }
            }
        }
        return START_STICKY;
    }

    private void parseCrosshairConfig(String jsonStr) {
        try {
            JSONObject obj = new JSONObject(jsonStr);
            if (obj.has("shape")) crosshairShape = obj.getString("shape");
            if (obj.has("color")) crosshairColor = Color.parseColor(obj.getString("color"));
            if (obj.has("size")) crosshairSizeDp = obj.getInt("size");
            if (obj.has("thickness")) crosshairStrokePx = obj.getInt("thickness");
            if (obj.has("offsetX")) crosshairOffsetX = obj.getInt("offsetX");
            if (obj.has("offsetY")) crosshairOffsetY = obj.getInt("offsetY");

            if (crosshairParams != null && crosshairView != null) {
                crosshairParams.x = crosshairOffsetX;
                crosshairParams.y = crosshairOffsetY;
                try {
                    windowManager.updateViewLayout(crosshairView, crosshairParams);
                } catch (Throwable ignored) {}
                crosshairView.invalidate();
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void onDestroy() {
        isRunning = false;

        if (wifiLock != null && wifiLock.isHeld()) {
            try {
                wifiLock.release();
            } catch (Throwable ignored) {}
        }

        if (batteryReceiver != null) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (Throwable ignored) {}
        }

        if (frameCallback != null) {
            try {
                Choreographer.getInstance().removeFrameCallback(frameCallback);
            } catch (Throwable ignored) {}
        }

        try {
            if (crosshairView != null) windowManager.removeView(crosshairView);
        } catch (Throwable ignored) {}
        try {
            if (pillView != null) windowManager.removeView(pillView);
        } catch (Throwable ignored) {}
        try {
            if (isHudVisible && hudView != null) windowManager.removeView(hudView);
        } catch (Throwable ignored) {}

        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private class CrosshairView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public CrosshairView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            paint.setColor(crosshairColor);
            paint.setStrokeWidth(crosshairStrokePx);
            paint.setStrokeCap(Paint.Cap.SQUARE);

            int cx = getWidth() / 2;
            int cy = getHeight() / 2;
            int radiusPx = dpToPx(crosshairSizeDp) / 2;
            int gapPx = Math.max(3, dpToPx(3));

            if ("DOT".equalsIgnoreCase(crosshairShape)) {
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy, Math.max(dpToPx(3), crosshairStrokePx * 1.5f), paint);
            } else if ("CIRCLE_DOT".equalsIgnoreCase(crosshairShape)) {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(cx, cy, radiusPx, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy, Math.max(dpToPx(2), crosshairStrokePx), paint);
            } else if ("T_POST".equalsIgnoreCase(crosshairShape)) {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawLine(cx - radiusPx, cy, cx - gapPx, cy, paint);
                canvas.drawLine(cx + gapPx, cy, cx + radiusPx, cy, paint);
                canvas.drawLine(cx, cy + gapPx, cx, cy + radiusPx, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy, Math.max(dpToPx(2), crosshairStrokePx), paint);
            } else {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawLine(cx - radiusPx, cy, cx - gapPx, cy, paint);
                canvas.drawLine(cx + gapPx, cy, cx + radiusPx, cy, paint);
                canvas.drawLine(cx, cy - radiusPx, cx, cy - gapPx, paint);
                canvas.drawLine(cx, cy + gapPx, cx, cy + radiusPx, paint);
            }
        }
    }
}
