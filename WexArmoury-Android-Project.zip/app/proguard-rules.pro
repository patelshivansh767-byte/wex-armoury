# Proguard rules for Wex Armoury
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.wex.armoury.** { *; }
